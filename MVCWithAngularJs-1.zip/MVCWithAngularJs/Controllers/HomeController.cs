﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCWithAngularJs.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Part2() // Fetch & Show Database Data
        {
            return View();
        }

        public ActionResult Part3() // Create Login Page
        {
            return View();
        }

        public ActionResult Part4() // Retrive & Display Tabuler Data
        {
            return View();
        }

        public ActionResult Part5() // Cascade Dropdown
        {
            return View();
        }

        public ActionResult Part6() // Simple registration with Validation
        {
            return View();
        }

    }
}
