﻿
namespace MVCWithAngularJs.Models
{
    public class LoginData
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}